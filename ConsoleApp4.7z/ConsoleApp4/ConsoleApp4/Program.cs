﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[40];
            int n = 0;
            int[] player1_draw= new int[20];
            int[] player2_draw = new int[20];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    arr[n] = j;
                    n++;
                }
            }
            int[] orgarr= randomize(arr, arr.Length);

            Array.Copy(orgarr,0,player1_draw, 0, 20);
            Array.Copy(orgarr, 20, player2_draw, 0, 20);
            PlayCard(player1_draw, player2_draw);

        }

        static void PlayCard(int [] arr1,int [] arr2)
        {
            int numlength;
            List<int> player1_discard = new List<int>();
            List<int> player2_discard = new List<int>();
            if (arr1.Length > 0 && arr2.Length > 0)
            {
                if (arr1.Length > arr2.Length)
                {
                    numlength = arr2.Length;
                }
                else
                {
                    numlength = arr1.Length;
                }
                List<int> list = new List<int>();
                for (int k = 0; k < numlength; k++)
                {
                    int num1 = arr1[k];
                    int num2 = arr2[k];
                    Console.WriteLine(num1);
                    Console.WriteLine(num2);
                    if (num1 > num2)
                    {
                        player1_discard.Add(num1);
                        player1_discard.Add(num2);
                        
                        Console.WriteLine("Player 1 is  winner in this turn.");
                        if (list.Count > 0)
                        {
                           player1_discard.AddRange(list);
                            list.Clear();
                        }
                    }
                    else if (num2 > num1)
                    {
                        player2_discard.Add(num1);
                        player2_discard.Add(num2);
                        Console.WriteLine("Player 2 is  winner in this turn");
                        if (list.Count > 0)
                        {
                            player2_discard.AddRange(list);
                            list.Clear();
                        }
                    }
                    else
                    {
                        Console.WriteLine("draw in this turn.");
                        list.Add(num1);
                        list.Add(num2);
                    }
                }
                if(player2_discard.Count==0)
                {
                    Console.WriteLine("Player 2 Losses...");
                }
                if (player1_discard.Count == 0)
                {
                    Console.WriteLine("Player 1 Losses...");
                }
                 
                if(player1_discard.Count > 0 && player2_discard.Count > 0)
                {
                    int[] player1 = randomize(player1_discard.ToArray(), player1_discard.Count);
                    int[] player2 = randomize(player2_discard.ToArray(), player2_discard.Count);
                    PlayCard(player1, player2);
                }
                
            }
        }
        static int[] randomize(int[] arr, int n)
        {
            Random r = new Random();
            for (int i = n - 1; i > 0; i--)
            {
                int j = r.Next(0, i + 1);
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            return arr;
        }
    }
}
